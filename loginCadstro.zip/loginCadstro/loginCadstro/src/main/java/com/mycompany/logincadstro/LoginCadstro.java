/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.logincadstro;

/**
 *
 * @author hyago
 */
public class LoginCadstro {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
